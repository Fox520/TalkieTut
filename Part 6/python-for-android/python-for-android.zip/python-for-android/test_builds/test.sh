#!/usr/bin/env sh

py.test -s
