'''
Stub functions for _scproxy on iOS
No proxy is supported yet.
'''


def _get_proxy_settings():
    return {'exclude_simple': 1}


def _get_proxies():
    return {}
