Contributing
============

The development of python-for-android is managed by the Kivy team `via
Github <https://github.com/kivy/python-for-android>`_.

Issues and pull requests are welcome via the integrated `issue tracker
<https://github.com/kivy/python-for-android/issues>`_.
